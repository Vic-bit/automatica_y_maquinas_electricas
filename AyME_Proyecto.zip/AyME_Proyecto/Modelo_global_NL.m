%Subsistema mec�nico
r=1/30
Jm=1200
Jl=100
bm=12
bl=10
Tm=500
Tl=20

%Modelo simplificado lineal invariante
Rs=10
Lq=4
Pp=2
lamdam=3

Ld=5
Lls=3
Rts=10
Cts=3