%Subsistema mec�nico
r=1/30
Jm=1200
Jl=100
bm=12
bl=10
Tm=500
Tl=20