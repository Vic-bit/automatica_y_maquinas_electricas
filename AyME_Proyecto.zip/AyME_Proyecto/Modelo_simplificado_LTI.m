%VALORES
Jm=3.1*(10^-6) %kg. m2
tolJl= 0.1260
Jl= 0.2520 %kg. m2

r=314.3008
Lq=5.8*(10^-3) %H
bm=1.5*(10^-5) %N.m/(rad/s)  
tolbl=0.0630
bl=0 %N.m/(rad/s)

Rs=1.02 %?
Pp=3 %pares
lambdam= 0.01546 %Wb - t, o (V/(rad/s))


%EQUIVALENCIAS
Jeq=Jm+(Jl/(r^2))
beq=bm+(bl/(r^2))
KT=(3/2)*Pp*lambdam
KE=Pp*lambdam

Cts=0.818
Rts=146.7
alphacu=3.9*10^(-3)
TsREF=40
RsREF=1.02

Ld=6.6*(10^-3)
Lls=0.8*(10^-3)

Rq=29
R0=4
Rd=33

Ksia=2893.3
Ksa=9.0416
ba=0.0113

%Ketheta=6400%-beq/Jeq
%Keomega=3200*3200%-beq/Jeq
Ketheta=9600
Keomega=3.072*(10^7)
Kei=3.2768*(10^10)

            

wnthetas=2000*3
zittathetas=1
wnis=6000*3
zittais=1
tauTs=20

a1theta=2*wnthetas*zittathetas
a2theta=wnthetas*wnthetas
b2theta=wnthetas*wnthetas 
a1i=2*wnis*zittais
a2i=wnis*wnis
b2i=wnis*wnis
a1Ts=1/tauTs
b2Ts=1/tauTs


%Calculos

coef2=(Jm+Jl*1/r^2)*Lq
coef1=(bm+bl*1/r^2)*Lq+(Jm+Jl*1/r^2)*Rs
coef0=(bm+bl*1/r^2)*Rs+3/2*Pp^2*lambdam^2

p = [coef2 coef1 coef0];
%r = roots(p)

frecnatural=((beq*Rs+3/2*Pp^2*lambdam^2)/(Jeq*Lq))^0.5
amortrelativo=(beq*Lq+Jeq*Rs)/(Jeq*Lq*2*frecnatural)